class NativeMetricSnapshot < MetricSnapshot
end
