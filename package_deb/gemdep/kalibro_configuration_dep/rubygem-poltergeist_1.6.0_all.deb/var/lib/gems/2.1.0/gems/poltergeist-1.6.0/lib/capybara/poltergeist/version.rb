module Capybara
  module Poltergeist
    VERSION = "1.6.0"
  end
end
