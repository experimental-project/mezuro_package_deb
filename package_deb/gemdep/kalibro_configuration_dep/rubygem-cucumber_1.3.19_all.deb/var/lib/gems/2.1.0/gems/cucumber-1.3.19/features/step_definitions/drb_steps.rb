Given /^I am running spork in the background$/ do
  run_spork_in_background
end