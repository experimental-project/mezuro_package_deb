module Arel
  module Nodes
    class BindParam < Node
    end
  end
end
