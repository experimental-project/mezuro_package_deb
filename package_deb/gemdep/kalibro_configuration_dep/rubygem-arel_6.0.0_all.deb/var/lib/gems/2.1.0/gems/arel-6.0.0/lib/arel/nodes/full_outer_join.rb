module Arel
  module Nodes
    class FullOuterJoin < Arel::Nodes::Join
    end
  end
end
