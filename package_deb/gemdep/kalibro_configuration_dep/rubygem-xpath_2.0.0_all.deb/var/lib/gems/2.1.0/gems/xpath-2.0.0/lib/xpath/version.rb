module XPath
  VERSION = '2.0.0'
end
