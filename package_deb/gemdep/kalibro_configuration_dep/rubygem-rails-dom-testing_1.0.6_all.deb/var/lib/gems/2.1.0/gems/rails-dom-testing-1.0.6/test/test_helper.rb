require 'nokogiri'
require 'active_support'
require 'active_support/test_case'
require 'minitest/autorun'

ActiveSupport::TestCase.test_order = :random
