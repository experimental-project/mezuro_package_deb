module Rails
  module Dom
    module Testing
      VERSION = "1.0.6"
    end
  end
end
