module I18n
  VERSION = "0.7.0"
end
