# encoding: utf-8

module Cliver
  # Cliver follows {http://semver.org SemVer}
  VERSION = '0.3.2'
end
