# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Dummy::Application.config.secret_key_base = '97a4619f221e596a6987a3e85838e6c65f225096496e0b01a52f4901e26339755682845a1c315969bb33ae8ebe1e3bedc698ec75ad4eb0c4c3dc9bd2338b1adf'
