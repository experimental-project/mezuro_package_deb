require 'rubygems'
require 'bundler/setup'

require 'sdoc'

require 'rdoc/test_case'

require 'minitest/autorun'
