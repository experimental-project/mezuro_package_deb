$:.unshift File.dirname(__FILE__)
require "rubygems"
gem 'rdoc'

module SDoc
end

require 'sdoc/generator'
