module SDoc
  VERSION = '0.4.1'
end
