module Mocha

  class NoYields

    def each
    end

  end

end

