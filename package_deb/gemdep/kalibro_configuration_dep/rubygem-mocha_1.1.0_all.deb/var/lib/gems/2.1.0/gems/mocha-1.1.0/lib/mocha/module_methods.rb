require 'mocha/module_method'

module Mocha

  # @private
  module ModuleMethods

    def stubba_method
      Mocha::ModuleMethod
    end

  end

end
