class Object

  # :stopdoc:

  alias_method :__is_a__, :is_a?

  # :startdoc:

end
