require "mocha/integration/mini_test"

Mocha::Integration::MiniTest.activate
