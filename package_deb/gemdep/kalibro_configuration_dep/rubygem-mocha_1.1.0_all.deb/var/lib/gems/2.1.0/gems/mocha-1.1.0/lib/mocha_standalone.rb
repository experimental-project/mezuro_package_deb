require 'mocha/api'
require 'mocha/deprecation'

Mocha::Deprecation.warning("`require 'mocha_standalone'` has been deprecated. Please use `require 'mocha/api' instead.")
