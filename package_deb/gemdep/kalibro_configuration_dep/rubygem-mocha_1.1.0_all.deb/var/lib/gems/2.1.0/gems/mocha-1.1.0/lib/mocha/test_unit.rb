require "mocha/integration/test_unit"

Mocha::Integration::TestUnit.activate
