### 0.1.2 / 2015-02-19

* Make it safe to call `Extensions#close` if the handshake is not complete

### 0.1.1 / 2014-12-14

* Explicitly require `strscan` which is not loaded in a vanilla Ruby environment

### 0.1.0 / 2014-12-13

* Initial release
