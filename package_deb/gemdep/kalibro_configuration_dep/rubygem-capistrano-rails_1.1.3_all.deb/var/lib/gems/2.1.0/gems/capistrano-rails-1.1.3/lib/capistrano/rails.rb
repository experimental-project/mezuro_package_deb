require 'capistrano/bundler'
require 'capistrano/rails/assets'
require 'capistrano/rails/migrations'
