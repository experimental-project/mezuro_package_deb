load File.expand_path("../../tasks/assets.rake", __FILE__)
