# Top level module for TZInfo.
module TZInfo
  # Top level module for TZInfo::Data.
  module Data
  end
end

require 'tzinfo/data/version'
