class Widget
  include ::MongoMapper::Document
  key :name, String
end
class Gadget
  include ::MongoMapper::Document
  key :name, String
end
