$LOAD_PATH.unshift(File.dirname(__FILE__) + '/../../lib')
require 'database_cleaner'

require 'rspec/expectations'
