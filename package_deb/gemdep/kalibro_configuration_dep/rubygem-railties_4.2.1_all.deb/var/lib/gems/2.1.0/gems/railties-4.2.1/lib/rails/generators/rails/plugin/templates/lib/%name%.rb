<% if engine? -%>
require "<%= name %>/engine"

<% end -%>
module <%= camelized %>
end
