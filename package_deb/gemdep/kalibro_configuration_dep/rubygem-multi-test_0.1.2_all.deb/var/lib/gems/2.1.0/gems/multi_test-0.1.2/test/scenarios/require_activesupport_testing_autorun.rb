require 'active_support/testing/autorun'

require "multi_test"
MultiTest.disable_autorun
