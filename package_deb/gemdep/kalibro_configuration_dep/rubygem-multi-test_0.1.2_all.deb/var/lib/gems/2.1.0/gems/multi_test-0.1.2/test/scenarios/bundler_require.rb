# Imagine this is your rails app
Bundler.require

# Now cucumber loads
require "multi_test"
MultiTest.disable_autorun

