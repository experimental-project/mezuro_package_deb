## [v0.1.2](https://github.com/cucumber/multi_test/compare/v0.1.1...v0.1.2)

* Ensure that detecting assetion library doesn't fail if no test framework
  included. Ruby 2.2 removed minitest from standard library. (@tooky, @jmoody)

## [v0.1.1](https://github.com/cucumber/multi_test/compare/v0.1.0...v0.1.1)

* Remove incompatibility with ruby 1.8.7

## [v0.1.0](https://github.com/cucumber/multi_test/compare/v0.0.3...v0.1.0)

* Detect best available assertion library for cucumber (@tooky)

## [v0.0.3](https://github.com/cucumber/multi_test/compare/v0.0.2...v0.0.3)

* Fix for Rails 4.1, Minitest 5.x ([#4](https://github.com/cucumber/multi_test/pull/4) Andy Lindeman)

## [v0.0.2](https://github.com/cucumber/multi_test/compare/bae4b700eb63cfb4e95f7acc35e25683f697905a...v0.0.2)

* First gem release
