module FactoryGirl
  VERSION = '4.5.0'
end
