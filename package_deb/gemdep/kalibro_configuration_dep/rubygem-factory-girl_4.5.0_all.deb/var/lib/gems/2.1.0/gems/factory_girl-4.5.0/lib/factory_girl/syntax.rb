require 'factory_girl/syntax/methods'
require 'factory_girl/syntax/default'

module FactoryGirl
  module Syntax
  end
end
