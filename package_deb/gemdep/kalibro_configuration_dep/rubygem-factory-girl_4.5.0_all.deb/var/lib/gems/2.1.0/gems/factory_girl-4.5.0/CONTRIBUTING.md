Contributing to factory\_girl:

1. Fork the [official repository](https://github.com/thoughtbot/factory_girl/tree/master).
2. Make your changes in a topic branch.
3. Send a pull request.

Notes:

* Contributions without tests won't be accepted.
* Please don't update the Gem version.
