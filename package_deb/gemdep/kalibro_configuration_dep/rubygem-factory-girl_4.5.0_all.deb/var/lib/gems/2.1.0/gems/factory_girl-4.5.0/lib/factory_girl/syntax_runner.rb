module FactoryGirl
  # @api private
  class SyntaxRunner
    include Syntax::Methods
  end
end
