module FactoryGirl
  module Strategy
    class Null
      def association(runner)
      end

      def result(evaluation)
      end
    end
  end
end
