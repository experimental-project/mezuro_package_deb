module Rails
  module DeprecatedSanitizer
    VERSION = "1.0.3"
  end
end
