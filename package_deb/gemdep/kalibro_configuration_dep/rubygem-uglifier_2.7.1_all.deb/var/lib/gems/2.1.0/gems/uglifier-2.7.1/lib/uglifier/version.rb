class Uglifier
  # Current version of Uglifier.
  VERSION = "2.7.1"
end
