module Shoulda
  module Matchers
    module ActiveRecord
      # @private
      module AssociationMatchers
      end
    end
  end
end
