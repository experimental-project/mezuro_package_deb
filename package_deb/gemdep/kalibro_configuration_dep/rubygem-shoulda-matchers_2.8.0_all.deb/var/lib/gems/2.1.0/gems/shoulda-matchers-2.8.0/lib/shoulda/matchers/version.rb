module Shoulda
  module Matchers
    # @private
    VERSION = '2.8.0'.freeze
  end
end
