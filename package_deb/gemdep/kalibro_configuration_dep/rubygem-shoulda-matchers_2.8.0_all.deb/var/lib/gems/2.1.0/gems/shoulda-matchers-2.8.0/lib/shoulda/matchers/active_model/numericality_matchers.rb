module Shoulda
  module Matchers
    module ActiveModel
      # @private
      module NumericalityMatchers
      end
    end
  end
end
