# encoding: utf-8
class EncodingTest
  def foo
    "ä"
  end
end
