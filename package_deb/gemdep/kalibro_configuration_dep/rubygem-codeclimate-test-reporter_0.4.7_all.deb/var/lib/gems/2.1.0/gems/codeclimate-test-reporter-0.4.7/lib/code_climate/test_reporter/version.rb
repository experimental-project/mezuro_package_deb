module CodeClimate
  module TestReporter
    VERSION = "0.4.7"
  end
end
