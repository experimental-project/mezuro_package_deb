# encoding: iso-8859-1
class EncodingTest
  def foo
    "�"
  end
end
