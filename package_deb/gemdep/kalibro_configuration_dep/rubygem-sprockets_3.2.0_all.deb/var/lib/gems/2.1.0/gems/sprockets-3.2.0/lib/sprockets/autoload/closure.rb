require 'closure-compiler'

module Sprockets
  module Autoload
    Closure = ::Closure
  end
end
