require 'sprockets/coffee_script_processor'

module Sprockets
  # Deprecated
  CoffeeScriptTemplate = CoffeeScriptProcessor
end
