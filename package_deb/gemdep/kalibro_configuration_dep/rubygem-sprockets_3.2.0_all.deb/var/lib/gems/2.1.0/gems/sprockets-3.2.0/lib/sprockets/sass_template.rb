require 'sprockets/sass_processor'

module Sprockets
  # Deprecated
  SassTemplate = SassProcessor
  ScssTemplate = ScssProcessor
end
