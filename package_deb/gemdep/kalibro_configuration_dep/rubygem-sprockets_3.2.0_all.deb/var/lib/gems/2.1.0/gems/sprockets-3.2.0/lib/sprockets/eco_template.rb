require 'sprockets/eco_processor'

module Sprockets
  # Deprecated
  EcoTemplate = EcoProcessor
end
