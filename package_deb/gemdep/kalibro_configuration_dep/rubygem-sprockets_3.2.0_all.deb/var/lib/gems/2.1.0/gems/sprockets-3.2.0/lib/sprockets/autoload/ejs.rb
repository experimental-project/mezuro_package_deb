require 'ejs'

module Sprockets
  module Autoload
    EJS = ::EJS
  end
end
