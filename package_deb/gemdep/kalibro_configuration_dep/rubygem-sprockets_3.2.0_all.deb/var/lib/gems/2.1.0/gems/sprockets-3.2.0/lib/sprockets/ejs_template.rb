require 'sprockets/ejs_processor'

module Sprockets
  # Deprecated
  EjsTemplate = EjsProcessor
end
