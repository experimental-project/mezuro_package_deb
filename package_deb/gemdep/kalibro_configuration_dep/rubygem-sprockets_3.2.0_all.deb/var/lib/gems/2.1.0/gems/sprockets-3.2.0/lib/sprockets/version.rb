module Sprockets
  VERSION = "3.2.0"
end
