require 'sass'

module Sprockets
  module Autoload
    Sass = ::Sass
  end
end
