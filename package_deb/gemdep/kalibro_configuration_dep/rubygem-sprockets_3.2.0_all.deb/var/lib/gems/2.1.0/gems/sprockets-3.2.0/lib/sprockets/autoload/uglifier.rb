require 'uglifier'

module Sprockets
  module Autoload
    Uglifier = ::Uglifier
  end
end
