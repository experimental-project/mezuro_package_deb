require 'sprockets/erb_processor'

module Sprockets
  # Deprecated
  ERBTemplate = ERBProcessor
end
