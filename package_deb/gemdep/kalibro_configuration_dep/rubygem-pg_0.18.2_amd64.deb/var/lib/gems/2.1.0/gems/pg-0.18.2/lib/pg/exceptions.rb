#!/usr/bin/env ruby

require 'pg' unless defined?( PG )


module PG

	class Error < StandardError; end

end # module PG

