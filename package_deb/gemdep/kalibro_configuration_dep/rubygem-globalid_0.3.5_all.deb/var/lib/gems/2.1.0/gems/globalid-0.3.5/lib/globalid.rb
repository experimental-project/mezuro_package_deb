require 'global_id'
require 'global_id/railtie'
