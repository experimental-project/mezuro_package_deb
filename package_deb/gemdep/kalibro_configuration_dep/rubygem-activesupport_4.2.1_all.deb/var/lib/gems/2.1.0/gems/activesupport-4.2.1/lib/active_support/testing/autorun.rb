gem 'minitest'

require 'minitest'

Minitest.autorun
