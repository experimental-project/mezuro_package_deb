module RSpec
  module Support
    module Version
      STRING = '3.2.2'
    end
  end
end
