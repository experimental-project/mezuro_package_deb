## Rails 4.2.1 (March 19, 2014) ##

* No Changes *


## Rails 4.2.0 (December 20, 2014) ##

*   New guide about constant autoloading and reloading.

    *Xavier Noria*

* Change Posts to Articles in Getting Started sample application in order to
better align with the actual guides.

    *John Kelly Ferguson*

* Update all Rails 4.1.0 references to 4.1.1 within the guides and code.

    *John Kelly Ferguson*

* Split up rows in the Explain Queries table of the ActiveRecord Querying section
in order to improve readability.

    *John Kelly Ferguson*

*   Change all non-HTTP method 'post' references to 'article'.

    *John Kelly Ferguson*

*   Updates the maintenance policy to match the latest versions of Rails

    *Matias Korhonen*

*   Switched the order of `Applying a default scope` and `Merging of scopes` subsections so default scopes are introduced first.

    *Alex Riabov*

Please check [4-1-stable](https://github.com/rails/rails/blob/4-1-stable/guides/CHANGELOG.md) for previous changes.
