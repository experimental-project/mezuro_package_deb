module Metaclass
end

require "metaclass/version"
require "metaclass/object_methods"
