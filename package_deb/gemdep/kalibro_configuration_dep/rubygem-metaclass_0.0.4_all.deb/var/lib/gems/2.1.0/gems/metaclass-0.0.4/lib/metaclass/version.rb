module Metaclass
  VERSION = "0.0.4"
end
