require "rubygems"
require "bundler/setup"

require "metaclass"
require "test/unit"
