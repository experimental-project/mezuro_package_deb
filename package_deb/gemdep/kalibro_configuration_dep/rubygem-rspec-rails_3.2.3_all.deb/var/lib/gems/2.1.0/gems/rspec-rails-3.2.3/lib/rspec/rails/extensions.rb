require 'rspec/rails/extensions/active_record/proxy'
