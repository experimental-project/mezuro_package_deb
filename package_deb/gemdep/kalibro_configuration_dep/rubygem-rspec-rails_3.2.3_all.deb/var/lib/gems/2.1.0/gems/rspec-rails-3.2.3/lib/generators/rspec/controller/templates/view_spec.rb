require 'rails_helper'

RSpec.describe "<%= file_name %>/<%= @action %>.html.<%= options[:template_engine] %>", <%= type_metatag(:view) %> do
  pending "add some examples to (or delete) #{__FILE__}"
end
