module RSpec
  module Rails
    # Version information for RSpec Rails.
    module Version
      # Current version of RSpec Rails, in semantic versioning format.
      STRING = '3.2.3'
    end
  end
end
