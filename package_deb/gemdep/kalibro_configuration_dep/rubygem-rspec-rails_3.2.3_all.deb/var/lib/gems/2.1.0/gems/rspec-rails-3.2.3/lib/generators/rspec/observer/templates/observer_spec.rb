require 'rails_helper'

<% module_namespacing do -%>
RSpec.describe <%= class_name %>Observer, <%= type_metatag(:observer) %> do
  pending "add some examples to (or delete) #{__FILE__}"
end
<% end -%>
