require 'rails_helper'

RSpec.describe "<%= file_path %>/<%= @action %>", <%= type_metatag(:view) %> do
  pending "add some examples to (or delete) #{__FILE__}"
end
