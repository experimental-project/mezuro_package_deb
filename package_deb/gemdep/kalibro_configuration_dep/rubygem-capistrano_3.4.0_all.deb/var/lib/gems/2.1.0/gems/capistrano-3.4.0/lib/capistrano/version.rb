module Capistrano
  VERSION = "3.4.0"
end
