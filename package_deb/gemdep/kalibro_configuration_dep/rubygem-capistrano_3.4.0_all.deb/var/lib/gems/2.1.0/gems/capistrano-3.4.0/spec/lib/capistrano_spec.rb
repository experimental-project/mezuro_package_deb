require 'spec_helper'

module Capistrano

  describe Application do
    let(:app) { Application.new  }
  end
end
