require 'test/unit'
require File.expand_path("../../lib/ref", __FILE__)
require File.expand_path("../reference_key_map_behavior", __FILE__)
require File.expand_path("../reference_value_map_behavior", __FILE__)
